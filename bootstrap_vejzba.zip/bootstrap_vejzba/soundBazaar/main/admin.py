from django.contrib import admin
from.models import PricingPlan, Song, ListOfFreeSong, ContactMessage

# Register your models here.

admin.site.register(PricingPlan)
admin.site.register(Song)
admin.site.register(ListOfFreeSong)
admin.site.register(ContactMessage)
