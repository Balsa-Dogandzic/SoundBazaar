from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('freeSongs/', views.freeSongs, name='freeSongs'),
    path('uploadPage/', views.uploadPage, name='uploadPage'),
    path('logIn/', views.logIn, name='logIn'),
    path('signUp/', views.signUp, name='signUp'),
    path('contact/', views.contact, name='contact'),
    path('success/', views.success, name='success'),
    path('rulesForSite/', views.rulesForSite, name='rulesForSite')
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
