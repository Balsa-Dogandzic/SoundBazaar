from django.contrib import messages
from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import PricingPlan, Song, ListOfFreeSong, ContactMessage

# Create your views here.

def index(request):
    return render(request, 'index.html', {})

def success(request):
    return render(request, 'success.html', {})

def about(request):
    plans = PricingPlan.objects.all()
    return render(request, 'about.html', {'plans': plans})

def freeSongs(request):
    songs = Song.objects.all()
    list_of_songs = ListOfFreeSong.objects.all()
    return render(request, 'freeSongs.html', {'songs': songs, 'list_of_songs': list_of_songs})

def uploadPage(request):
    return render(request, 'uploadPage.html', {})

def logIn(request):
    return render(request, 'logIn.html', {})

def signUp(request):
    return render(request, 'signUp.html', {})

def contact(request):
    if request.method == "POST":
        kontaktPoruka = ContactMessage()
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        kontaktPoruka.full_name = full_name
        kontaktPoruka.email = email
        kontaktPoruka.message = message

        kontaktPoruka.save()

        return redirect('success')

    return render(request, 'contact.html', {})

def rulesForSite(request):
    return render(request, 'rulesForSite.html', {})

