from django.db import models

# Create your models here.

class PricingPlan(models.Model):
    title = models.CharField(max_length=100)
    free = models.CharField(max_length=100)
    pro = models.CharField(max_length=100)
    enterprise = models.CharField(max_length=100)

    def __str__(self):
        return self.title

class Song(models.Model):
    author = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    key = models.CharField(max_length=50)
    genre = models.CharField(max_length=50)
    bpm = models.IntegerField()
    time = models.CharField(max_length=20)
    download_available = models.BooleanField(default=False)

    def __str__(self):
        return self.title


class ListOfFreeSong(models.Model):
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=100)
    audio_file = models.FileField(upload_to='freeAudio/')
    picture_for_freeSongs = models.ImageField(upload_to='album_for_freeSongs/', null=True, blank=False)
    allow_download = models.BooleanField(default=True)

    def __str__(self):
        return f"Title: {self.title} - Author: {self.author}"

class ContactMessage(models.Model):
    full_name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()

    def __str__(self):
        return f"Poruka od: {self.full_name}"